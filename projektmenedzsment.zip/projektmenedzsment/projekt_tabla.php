<?php
// projekt_tabla.php
require 'adatbazis.php'; // itt legyen a $conn kapcsolat

// Szűrési feltételek lekérése
$szures = [];
$param = [];
if (isset($_GET['allapot']) && $_GET['allapot'] === 'nyitott') {
    $szures[] = "veg >= CURDATE()";
}
if (isset($_GET['datum']) && $_GET['datum'] !== '') {
    $szures[] = "kezdet <= :datum AND veg >= :datum";
    $param[':datum'] = $_GET['datum'];
}

// Lekérdezés projektekre, nyitottak felül
$sql = "SELECT id, nev, kezdet, veg, leiras FROM projektek";
if ($szures) {
    $sql .= " WHERE " . implode(" AND ", $szures);
}
$sql .= " ORDER BY veg >= CURDATE() DESC, kezdet"; // nyitottak felül

$stmt = $conn->prepare($sql);
$stmt->execute($param);
$projektek = $stmt->fetchAll(PDO::FETCH_ASSOC);

$statuszUzenet = '';
if (isset($_GET['status'])) {
    switch ($_GET['status']) {
        case 'ok':
            $statuszUzenet = "A módosítás sikeresen megtörtént.";
            break;
        case 'hiba':
            $statuszUzenet = "Hiba történt a mentés során!";
            break;
        default:
            $statuszUzenet = '';
    }
}
?>

<div>
    <h1>Projektek</h1>
    <?php if ($statuszUzenet): ?>
        <p style="color: green; font-weight: bold;"><?= htmlspecialchars($statuszUzenet) ?></p>
    <?php endif; ?>
</div>

<form method="get" action="admin.php">
    <input type="hidden" name="lap" value="projektek">
    <label>
        Állapot:
        <select name="allapot">
            <option value="">Mind</option>
            <option value="nyitott" <?= (isset($_GET['allapot']) && $_GET['allapot']=='nyitott')?'selected':'' ?>>Nyitott</option>
        </select>
    </label>
    <label>
        Dátum:
        <input type="date" name="datum" value="<?= isset($_GET['datum']) ? htmlspecialchars($_GET['datum']) : '' ?>">
    </label>
    <button type="submit">Szűrés</button>
</form>

<table border="1" cellpadding="5" cellspacing="0">
    <thead>
        <tr>
            <th>Név</th>
            <th>Kezdet</th>
            <th>Vége</th>
            <th>Leírás</th>
            <th>Műveletek</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($projektek as $projekt): ?>
        <tr>
            <td><?= htmlspecialchars($projekt['nev']) ?></td>
            <td><?= htmlspecialchars($projekt['kezdet']) ?></td>
            <td><?= htmlspecialchars($projekt['veg']) ?></td>
            <td><?= htmlspecialchars($projekt['leiras']) ?></td>
            <td>
                <a href="admin.php?lap=projekt_modosit&id=<?= $projekt['id'] ?>">Módosítás</a> |
                <a href="admin.php?lap=projekt_nap_szervez&id=<?= $projekt['id'] ?>">Nap szervezés</a> |
                <a href="admin.php?lap=projekt_lezaras&id=<?= $projekt['id'] ?>" onclick="return confirm('Biztos lezárod a projektet?')">Lezárás</a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<div>
<a href="admin.php?lap=uj_projekt">Új projekt</a>
</div>
