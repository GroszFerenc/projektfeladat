<?php
// dolgozok_tabla.php
require 'adatbazis.php'; // itt legyen a $conn kapcsolat

// Lekérdezés az összes dolgozóról
$sql = "SELECT id, valodi_nev, jogosultsag FROM dolgozok ORDER BY id";
$stmt = $conn->prepare($sql);
$stmt->execute();
$dolgozok = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Jogosultság szöveggé alakítása
function jogosultsagSzoveg($szint) {
    return match($szint) {
        1 => "Adminisztrátor",
        2 => "Szakember",
        3 => "Segédmunkás",
        default => "Ismeretlen",
    };
}
$statuszUzenet = '';
if (isset($_GET['status'])) {
    switch ($_GET['status']) {
        case 'ok':
            $statuszUzenet = "A módosítás sikeresen megtörtént.";
            break;
        case 'hiba':
            $statuszUzenet = "Hiba történt a mentés során!";
            break;
        default:
            $statuszUzenet = '';
    }
}
?>


<div>
    <h1>Dolgozók</h1>
    <?php if ($statuszUzenet): ?>
        <p style="color: green; font-weight: bold;"><?= htmlspecialchars($statuszUzenet) ?></p>
    <?php endif; ?>
</div>
<table border="1" cellpadding="5" cellspacing="0">
    <thead>
        <tr>
            <th>ID</th>
            <th>Név</th>
            <th>Jogosultság</th>
            <th>Műveletek</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($dolgozok as $dolgozo): ?>
        <tr>
            <td><?= htmlspecialchars($dolgozo['id']) ?></td>
            <td><?= htmlspecialchars($dolgozo['valodi_nev']) ?></td>
            <td><?= jogosultsagSzoveg($dolgozo['jogosultsag']) ?></td>
            <td>
                <a href="admin.php?lap=modosit&id=<?= $dolgozo['id'] ?>">Módosítás</a> |
                <a href="admin.php?lap=jelszo_modosit&id=<?= $dolgozo['id'] ?>">Jelszó módosítás</a> |
                <a href="dolgozo_torles.php?id=<?= $dolgozo['id'] ?>" onclick="return confirm('Biztos törlöd a dolgozót?')">Törlés</a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<div>
<a href="admin.php?lap=uj_dolgozo">Új dolgozó</a>
</div>
