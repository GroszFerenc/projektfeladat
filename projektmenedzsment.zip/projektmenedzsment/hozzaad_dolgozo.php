<?php
require 'adatbazis.php';

$napId = $_POST['napId'];
$dolgozoId = $_POST['dolgozoId'];

// Ellenőrizzük, hogy már nincs-e hozzáadva
$check = $pdo->prepare("SELECT id FROM projekt_nap_dolgozo WHERE projekt_nap_id=? AND dolgozo_id=?");
$check->execute([$napId, $dolgozoId]);
if(!$check->fetch()) {
    $stmt = $pdo->prepare("INSERT INTO projekt_nap_dolgozo (projekt_nap_id, dolgozo_id) VALUES (?, ?)");
    $stmt->execute([$napId, $dolgozoId]);
}

// Visszaadjuk a friss listát
$dolgozokNap = $pdo->prepare("SELECT d.nev FROM projekt_nap_dolgozo pnd JOIN dolgozok d ON pnd.dolgozo_id=d.id WHERE pnd.projekt_nap_id=?");
$dolgozokNap->execute([$napId]);
foreach ($dolgozokNap->fetchAll() as $d) {
    echo "<li>".htmlspecialchars($d['nev'])."</li>";
}
