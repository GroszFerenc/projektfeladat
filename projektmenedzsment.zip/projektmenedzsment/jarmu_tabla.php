<?php
// jarmuvek.php
require 'adatbazis.php'; // itt legyen a $conn kapcsolat

// Lekérdezés az összes járműről
$sql = "SELECT id, rendszam, uzemanyag FROM jarmu ORDER BY rendszam";
$stmt = $conn->prepare($sql);
$stmt->execute();
$jarmuvek = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Statusz üzenet
$statuszUzenet = '';
if (isset($_GET['status'])) {
    switch ($_GET['status']) {
        case 'ok':
            $statuszUzenet = "A művelet sikeresen megtörtént.";
            break;
        case 'hiba':
            $statuszUzenet = "Hiba történt a mentés során!";
            break;
        default:
            $statuszUzenet = '';
    }
}
?>

<div>
    <h1>Járművek</h1>
    <?php if ($statuszUzenet): ?>
        <p style="color: green; font-weight: bold;"><?= htmlspecialchars($statuszUzenet) ?></p>
    <?php endif; ?>
</div>

<table border="1" cellpadding="5" cellspacing="0">
    <thead>
        <tr>
            <th>Rendszám</th>
            <th>Üzemanyag</th>
            <th>Műveletek</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($jarmuvek as $jarmu): ?>
        <tr>
            <td><?= htmlspecialchars($jarmu['rendszam']) ?></td>
            <td><?= htmlspecialchars($jarmu['uzemanyag']) ?></td>
            <td>
                <a href="admin.php?lap=jarmu_modosit&id=<?= $jarmu['id'] ?>">Módosítás</a> |
                <a href="jarmu_torles.php?id=<?= $jarmu['id'] ?>" onclick="return confirm('Biztos törlöd a járművet?')">Törlés</a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<div>
    <a href="admin.php?lap=uj_jarmu">Új jármű</a>
</div>
