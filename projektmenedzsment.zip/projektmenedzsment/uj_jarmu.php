<?php
// uj_jarmu.php
require 'adatbazis.php'; // itt legyen a $conn kapcsolat

// Jogosultság ellenőrzése (csak Admin, azaz jogosultsag=1)
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] != 1) {
    header('Location: index.php');
    exit;
}

// Statusz üzenet (opcionális, ha visszajelzés kell)
$statuszUzenet = '';
if (isset($_GET['status'])) {
    switch ($_GET['status']) {
        case 'hiba':
            $statuszUzenet = "Hiba történt a jármű hozzáadásakor!";
            break;
        default:
            $statuszUzenet = '';
    }
}
?>

<div>
    <h1>Új jármű hozzáadása</h1>
    <?php if ($statuszUzenet): ?>
        <p style="color: red; font-weight: bold;"><?= htmlspecialchars($statuszUzenet) ?></p>
    <?php endif; ?>
</div>

<form action="jarmu_hozzaad.php" method="post">
    <div>
        <label for="rendszam">Rendszám:</label>
        <input type="text" name="rendszam" id="rendszam" required>
    </div>
    <div>
        <label for="uzemanyag">Üzemanyag:</label>
        <input type="text" name="uzemanyag" id="uzemanyag" required>
    </div>
    <div>
        <button type="submit">Mentés</button>
    </div>
</form>
