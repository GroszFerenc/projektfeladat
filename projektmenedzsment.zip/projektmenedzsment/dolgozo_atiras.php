<?php
session_start();
require_once "adatbazis.php";

// Jogosultság ellenőrzése
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] != 1) {
    header("Location: index.php?error=Nem+megfelelő+jogosultság!");
    exit;
}

// GET-ből az ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Hibás dolgozó azonosító!");
}
$modositando_id = (int)$_GET['id'];

// POST ellenőrzése
if (!isset($_POST['felh_nev'], $_POST['valodi_nev'], $_POST['jogosultsag'])) {
    die("Hiányzó adatok!");
}

$felh_nev = trim($_POST['felh_nev']);
$valodi_nev = trim($_POST['valodi_nev']);
$jogosultsag = (int)$_POST['jogosultsag'];

// Egyszerű validálás
if (empty($felh_nev) || empty($valodi_nev) || $jogosultsag < 1 || $jogosultsag > 3) {
    die("Hibás adatok!");
}

// Dolgozó adatainak frissítése
$stmt = $conn->prepare("UPDATE dolgozok SET felh_nev = ?, valodi_nev = ?, jogosultsag = ? WHERE id = ?");
$result = $stmt->execute([$felh_nev, $valodi_nev, $jogosultsag, $modositando_id]);

if ($result) {
    header("Location: admin.php?lap=dolgozok&status=ok");
    exit;
} else {
    die("Hiba történt a módosítás során!");
}
?>
