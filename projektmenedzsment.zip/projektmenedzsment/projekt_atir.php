<?php
// projekt_atir.php
require 'adatbazis.php';
session_start();

// Jogosultság ellenőrzés
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] != 1) {
    header("Location: admin.php?lap=projektek&status=1");
    exit;
}

// Ellenőrizzük, hogy POST-ból jöttek-e az adatok
if (!isset($_POST['id'], $_POST['nev'], $_POST['leiras'], $_POST['kezdet'])) {
    header("Location: admin.php?lap=projektek&status=2");
    exit;
}

$id = intval($_POST['id']);
$nev = trim($_POST['nev']);
$leiras = trim($_POST['leiras']);
$kezdete = $_POST['kezdet'];

// Frissítés az adatbázisban
try {
    $sql = "UPDATE projektek 
            SET nev = :nev, leiras = :leiras, kezdet = :kezdete 
            WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':nev' => $nev,
        ':leiras' => $leiras,
        ':kezdete' => $kezdete,
        ':id' => $id
    ]);

    header("Location: admin.php?lap=projektek&status=ok");
    exit;
} catch (PDOException $e) {
    // Hibás eset
    header("Location: admin.php?lap=projektek&status=3");
    exit;
}
?>
