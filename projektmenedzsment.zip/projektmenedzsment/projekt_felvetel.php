<?php
// projekt_felvetel.php
session_start();
require 'adatbazis.php';

// Jogosultság ellenőrzése: csak Admin (1) és Szakember (2)
if (!isset($_SESSION['jogosultsag']) || !in_array($_SESSION['jogosultsag'], [1,2])) {
    header('Location: admin.php?lap=projektek&status=hiba');
    exit;
}

// POST adatok lekérése
$nev = $_POST['nev'] ?? '';
$kezdet = $_POST['kezdet'] ?? '';
$leiras = $_POST['leiras'] ?? '';

// Egyszerű validálás
if (empty($nev) || empty($kezdet)) {
    header('Location: admin.php?lap=projektek&status=hiba');
    exit;
}

try {
    $sql = "INSERT INTO projektek (nev, kezdet,leiras) VALUES (:nev, :kezdet, :leiras)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':nev' => $nev,
        ':kezdet' => $kezdet,
        ':leiras' => $leiras
    ]);

    // Sikeres beszúrás
    header('Location: admin.php?lap=projektek&status=ok');
    exit;

} catch (PDOException $e) {
    // Hibakezelés
    header('Location: admin.php?lap=projektek&status=hiba');
    exit;
}
