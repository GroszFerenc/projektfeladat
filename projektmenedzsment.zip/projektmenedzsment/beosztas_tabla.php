<?php

require 'db.php'; // PDO adatbázis kapcsolat

// Bejelentkezett dolgozó ellenőrzése
$dolgozo_id = $_SESSION['id'] ?? 0;
if ($dolgozo_id == 0) {
    die("Nincs bejelentkezett dolgozó.");
}

// Hét módosítása GET paraméterrel
$weekOffset = isset($_GET['week']) ? intval($_GET['week']) : 0;

// Hétfő kezdő és vasárnap végdátuma
$het_kezdete = date('Y-m-d', strtotime("monday this week +$weekOffset week"));
$het_vege = date('Y-m-d', strtotime("$het_kezdete +6 days"));

// Heti beosztás lekérdezése – csak a bejelentkezett dolgozó projektjei
$sql = "
SELECT pn.datum, p.nev AS projekt_nev, pn.leiras AS nap_leiras, j.rendszam AS jarmu_rendszam
FROM projekt_napok pn
JOIN projektek p ON pn.projekt_id = p.id
JOIN projekt_nap_dolgozo pnd ON pn.id = pnd.projekt_nap_id AND pnd.dolgozo_id = :dolgozo_id
LEFT JOIN projekt_nap_auto pna ON pn.id = pna.projekt_nap_id
LEFT JOIN jarmu j ON pna.jarmu_id = j.id
WHERE pn.datum BETWEEN :het_kezdete AND :het_vege
ORDER BY pn.datum
";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    ':dolgozo_id' => $dolgozo_id,
    ':het_kezdete' => $het_kezdete,
    ':het_vege' => $het_vege
]);
$beosztas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Napok előkészítése
$napok = [];
for ($i = 0; $i < 7; $i++) {
    $nap = date('Y-m-d', strtotime("$het_kezdete +$i days"));
    $napok[$nap] = [];
}

// Napok feltöltése beosztás adataival
foreach ($beosztas as $sor) {
    $napok[$sor['datum']][] = $sor;
}

// Szabadságok lekérdezése
$stmt = $pdo->prepare("SELECT nap FROM szabadsag WHERE dolgozo_id = :dolgozo_id AND nap BETWEEN :het_kezdete AND :het_vege");
$stmt->execute([
    ':dolgozo_id' => $dolgozo_id,
    ':het_kezdete' => $het_kezdete,
    ':het_vege' => $het_vege
]);
$szabadsagok = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);

// Magyar napok nevei
$nap_nevek = [
    'Monday' => 'hétfő',
    'Tuesday' => 'kedd',
    'Wednesday' => 'szerda',
    'Thursday' => 'csütörtök',
    'Friday' => 'péntek',
    'Saturday' => 'szombat',
    'Sunday' => 'vasárnap'
];

// GET paraméterek megtartása a linkekhez
$params = $_GET;
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Heti Beosztás</title>
<style>
    body { font-family: Arial, sans-serif; }
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: left; vertical-align: top; }
    th { background-color: #f2f2f2; }
    td.empty { color: #aaa; font-style: italic; }
    td.szabadsag { background-color: #ffcccc; font-weight: bold; text-align: center; }
    .szabadsag-text { color: red; font-weight: bold; }
    .nav { margin-bottom: 15px; }
</style>
</head>
<body>

<h2> Heti beosztás: <?php echo htmlspecialchars($het_kezdete); ?> – <?php echo htmlspecialchars($het_vege); ?></h2>

<div class="nav">
    <?php
        $params['week'] = $weekOffset - 1;
        echo '<a href="?' . http_build_query($params) . '">Előző hét</a> | ';
        $params['week'] = 0;
        echo '<a href="?' . http_build_query($params) . '">Aktuális hét</a> | ';
        $params['week'] = $weekOffset + 1;
        echo '<a href="?' . http_build_query($params) . '">Következő hét</a>';
    ?>
</div>

<table>
    <tr>
        <th>Nap</th>
        <th>Projekt</th>
        <th>Leírás</th>
        <th>Jármű</th>
    </tr>
    <?php foreach ($napok as $datum => $nap_adatok): ?>
        <?php $isSzabadsag = in_array($datum, $szabadsagok); ?>
        <?php if (count($nap_adatok) > 0 || $isSzabadsag): ?>
            <?php foreach ($nap_adatok as $index => $adat): ?>
                <tr>
                    <?php if ($index == 0): ?>
                        <td rowspan="<?php echo max(1, count($nap_adatok)); ?>">
                            <?php echo $nap_nevek[date('l', strtotime($datum))] . ', ' . $datum; ?>
                            <?php if ($isSzabadsag): ?>
                                <span class="szabadsag-text"> – Szabadság</span>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                    <td><?php echo htmlspecialchars($adat['projekt_nev']); ?></td>
                    <td><?php echo htmlspecialchars($adat['nap_leiras']); ?></td>
                    <td><?php echo htmlspecialchars($adat['jarmu_rendszam']); ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if ($isSzabadsag && count($nap_adatok) == 0): ?>
                <tr>
                    <td colspan="3" class="szabadsag-text" style="text-align:center;">Szabadság</td>
                </tr>
            <?php endif; ?>
        <?php else: ?>
            <tr>
                <td><?php echo $nap_nevek[date('l', strtotime($datum))] . ', ' . $datum; ?></td>
                <td class="empty" colspan="3">Nincs beosztás</td>
            </tr>
        <?php endif; ?>
    <?php endforeach; ?>
</table>

</body>
</html>
