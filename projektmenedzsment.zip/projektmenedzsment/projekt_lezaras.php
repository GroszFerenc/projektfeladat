<?php
// projekt_lezaras.php

require 'adatbazis.php';

// Jogosultság ellenőrzés
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] != 1) {
    header("Location: admin.php?lap=projektek&status=hiba");
    exit;
}

// Ellenőrizzük, hogy kapunk-e projekt ID-t GET-ből
if (!isset($_GET['id'])) {
    header("Location: admin.php?lap=projektek&status=hiba");
    exit;
}

$id = intval($_GET['id']);
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Projekt lezárása</title>
</head>
<body>
    <h2>Projekt lezárása</h2>
    <form action="projekt_kesz.php" method="post">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <label for="vege">Lezárás dátuma:</label>
        <input type="date" id="veg" name="veg" required>
        <br><br>
        <input type="submit" value="Lezárás">
    </form>
</body>
</html>
