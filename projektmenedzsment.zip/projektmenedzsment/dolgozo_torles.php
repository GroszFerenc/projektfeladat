<?php
session_start();
require_once "adatbazis.php"; // a PDO kapcsolatot tartalmazó fájl

// Jogosultság ellenőrzés
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] != 1) {
    header("Location: index.php");
    exit;
}

// ID ellenőrzés
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: admin.php?lap=dolgozok");
    exit;
}

$id = (int)$_GET['id'];

try {
    // Tranzakció indítása
    $conn->beginTransaction();

    // Kapcsolódó sorok törlése a projekt_nap_dolgozo táblából
    $stmt = $conn->prepare("DELETE FROM projekt_nap_dolgozo WHERE dolgozo_id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    // Dolgozó törlése
    $stmt = $conn->prepare("DELETE FROM dolgozok WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    // Tranzakció véglegesítése
    $conn->commit();

} catch (Exception $e) {
    // Hiba esetén visszagörgetjük a tranzakciót
    $conn->rollBack();
    // Hibakezelés: logolhatod, vagy átirányíthatsz egy hibaoldalra
    die("Hiba történt a törlés során: " . $e->getMessage());
}

// Vissza a dolgozók listához
header("Location: admin.php?lap=dolgozok");
exit;
