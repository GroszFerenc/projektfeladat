<?php
require 'adatbazis.php';

$napId = $_POST['napId'];
$jarmuId = $_POST['jarmuId'];

// Egy napra csak egy jármű lehet
$pdo->prepare("DELETE FROM projekt_nap_auto WHERE projekt_nap_id=?")->execute([$napId]);

$stmt = $pdo->prepare("INSERT INTO projekt_nap_auto (projekt_nap_id, jarmu_id) VALUES (?, ?)");
$stmt->execute([$napId, $jarmuId]);

$jarmuvekNap = $pdo->prepare("SELECT j.nev FROM projekt_nap_auto pna JOIN jarmuvek j ON pna.jarmu_id=j.id WHERE pna.projekt_nap_id=?");
$jarmuvekNap->execute([$napId]);
foreach ($jarmuvekNap->fetchAll() as $j) {
    echo "<li>".htmlspecialchars($j['nev'])."</li>";
}
