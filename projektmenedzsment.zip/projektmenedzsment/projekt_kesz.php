<?php
// projekt_kesz.php
session_start();
require 'adatbazis.php';

// Jogosultság ellenőrzés
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] != 1) {
    header("Location: admin.php?lap=projektek&status=hiba");
    exit;
}

// Ellenőrizzük, hogy POST-ból jöttek-e az adatok
if (!isset($_POST['id'], $_POST['veg'])) {
    header("Location: admin.php?lap=projektek&status=hiba");
    exit;
}

$id = intval($_POST['id']);
$vege = $_POST['veg']; // formátum: YYYY-MM-DD

try {
    // Frissítés az adatbázisban
    $sql = "UPDATE projektek 
            SET veg = :vege 
            WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':vege' => $vege,
        ':id' => $id
    ]);

    // Visszairányítás sikerrel
    header("Location: admin.php?lap=projektek&status=ok");
    exit;

} catch (PDOException $e) {
    // Hiba esetén
    header("Location: admin.php?lap=projektek&status=hiba");
    exit;
}
?>
