<?php
require 'adatbazis.php';
$projekt_id = intval($_GET['id']);
$nap = $_GET['nap'];

$stmt = $conn->prepare("
    SELECT j.rendszam 
    FROM projekt_nap_auto pna
    JOIN projekt_napok pn ON pna.projekt_nap_id = pn.id
    JOIN jarmu j ON pna.jarmu_id = j.id
    WHERE pn.projekt_id = :pid AND pn.datum = :nap
");
$stmt->execute([':pid'=>$projekt_id, ':nap'=>$nap]);
$jarmuvek = $stmt->fetchAll(PDO::FETCH_COLUMN);

$stmt = $conn->prepare("
    SELECT d.valodi_nev
    FROM projekt_nap_dolgozo pnd
    JOIN projekt_napok pn ON pnd.projekt_nap_id = pn.id
    JOIN dolgozok d ON pnd.dolgozo_id = d.id
    WHERE pn.projekt_id = :pid AND pn.datum = :nap
");
$stmt->execute([':pid'=>$projekt_id, ':nap'=>$nap]);
$dolgozok = $stmt->fetchAll(PDO::FETCH_COLUMN);

echo json_encode(['jarmuvek'=>$jarmuvek, 'dolgozok'=>$dolgozok]);
