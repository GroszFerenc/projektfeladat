<?php
// nap_szervezes.php - javított verzió (szabadság div + kizárás a szabad listából)

if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] != 1) {
    header("Location: index.php");
    exit;
}

require 'db.php';

$datum = $_GET['datum'] ?? date('Y-m-d');

// Számoljuk az előző és következő napot
$elso_link = date('Y-m-d', strtotime($datum . ' -1 day'));
$utolso_link = date('Y-m-d', strtotime($datum . ' +1 day'));

// Projektek a kiválasztott napra
$stmt = $pdo->prepare("
    SELECT p.id AS projekt_id, p.nev, pn.id AS projekt_nap_id, pn.leiras
    FROM projektek p
    LEFT JOIN projekt_napok pn ON pn.projekt_id = p.id AND pn.datum = ?
    WHERE p.kezdet <= ? AND (p.veg IS NULL OR p.veg >= ?)
");
$stmt->execute([$datum, $datum, $datum]);
$projektek = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Szabadságolt dolgozók (az adott napra)
$stmtSzabadsag = $pdo->prepare("
    SELECT d.id, d.valodi_nev 
    FROM dolgozok d 
    JOIN szabadsag s ON s.dolgozo_id = d.id 
    WHERE s.nap = ?
");
$stmtSzabadsag->execute([$datum]);
$szabadsagolt_dolgozok = $stmtSzabadsag->fetchAll(PDO::FETCH_ASSOC);
$szabadsagolt_ids = array_map('intval', array_column($szabadsagolt_dolgozok, 'id'));

// Ki nem osztott dolgozók (kivéve a szabadságoltakat)
$exclude_ids_sql = $szabadsagolt_ids ? implode(',', $szabadsagolt_ids) : '0';
$stmtDolgozok = $pdo->prepare("
    SELECT * FROM dolgozok
    WHERE id NOT IN (
        SELECT dolgozo_id 
        FROM projekt_nap_dolgozo 
        WHERE projekt_nap_id IN (
            SELECT id FROM projekt_napok WHERE datum=?
        )
    )
    AND id NOT IN ($exclude_ids_sql)
");
$stmtDolgozok->execute([$datum]);
$ki_nem_osztott_dolgozok = $stmtDolgozok->fetchAll(PDO::FETCH_ASSOC);

// Ki nem osztott járművek
$stmtJarmuvek = $pdo->prepare("
    SELECT * FROM jarmu
    WHERE id NOT IN (
        SELECT jarmu_id 
        FROM projekt_nap_auto 
        WHERE projekt_nap_id IN (
            SELECT id FROM projekt_napok WHERE datum=?
        )
    )
");
$stmtJarmuvek->execute([$datum]);
$ki_nem_osztott_jarmuvek = $stmtJarmuvek->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Projekt Menedzsment - Nap szervezés</title>
<style>
body { font-family: Arial; }
.container { display: flex; gap: 20px; flex-wrap: wrap; }
.list, .project { border: 1px solid #ccc; padding: 10px; min-width: 200px; min-height: 200px; }
.item { margin: 5px; padding: 5px; background: #eee; cursor: grab; }
.assigned { min-height: 50px; }
.szabadsag { border: 1px solid #f00; background: #fee; min-width: 200px; min-height: 50px; }
.nav-links { margin-bottom: 10px; }
.nav-links a { margin-right: 10px; text-decoration: none; color: blue; }
textarea.leiras { width: 100%; min-height: 60px; margin-top: 5px; }
</style>
</head>
<body>

<h2>Válassz dátumot:</h2>

<div class="nav-links">
    <a href="?lap=nap_szervezes&datum=<?= $elso_link ?>">&laquo; Előző nap</a>
    <input type="date" id="datum" value="<?= htmlspecialchars($datum) ?>">
    <a href="?lap=nap_szervezes&datum=<?= $utolso_link ?>">Következő nap &raquo;</a>
</div>



<div class="container">
    <div class="list szabadsag" id="szabadsag">
        <h3>Szabadság</h3>
        <?php foreach($szabadsagolt_dolgozok as $d): ?>
            <div class="item" data-id="<?= $d['id'] ?>" data-tipus="dolgozo"><?= htmlspecialchars($d['valodi_nev']) ?></div>
        <?php endforeach; ?>
    </div>

    <div class="list" id="dolgozok">
        <h3>Dolgozók</h3>
        <?php foreach($ki_nem_osztott_dolgozok as $d): ?>
            <div class="item" draggable="true" data-id="<?= $d['id'] ?>" data-tipus="dolgozo"><?= htmlspecialchars($d['valodi_nev']) ?></div>
        <?php endforeach; ?>
    </div>

    <div class="list" id="jarmuvek">
        <h3>Járművek</h3>
        <?php foreach($ki_nem_osztott_jarmuvek as $j): ?>
            <div class="item" draggable="true" data-id="<?= $j['id'] ?>" data-tipus="jarmu"><?= htmlspecialchars($j['rendszam']) ?></div>
        <?php endforeach; ?>
    </div>

    <div style="flex-basis: 100%; height: 0;"></div>

    <?php foreach($projektek as $p):
        $projekt_nap_id = $p['projekt_nap_id'] ?? null;
        $leiras = $p['leiras'] ?? '';

        $dolgozok = [];
        $jarmuvek = [];

        if($projekt_nap_id){
            // Dolgozók
            $stmtPD = $pdo->prepare("
                SELECT d.valodi_nev 
                FROM dolgozok d 
                JOIN projekt_nap_dolgozo pd ON d.id=pd.dolgozo_id 
                WHERE pd.projekt_nap_id = ?
            ");
            $stmtPD->execute([$projekt_nap_id]);
            $dolgozok = $stmtPD->fetchAll(PDO::FETCH_ASSOC);

            // Járművek
            $stmtPA = $pdo->prepare("
                SELECT j.rendszam 
                FROM jarmu j 
                JOIN projekt_nap_auto pa ON j.id=pa.jarmu_id 
                WHERE pa.projekt_nap_id = ?
            ");
            $stmtPA->execute([$projekt_nap_id]);
            $jarmuvek = $stmtPA->fetchAll(PDO::FETCH_ASSOC);
        }
    ?>
    <div class="project" data-id="<?= $projekt_nap_id ?>" data-projekt-id="<?= $p['projekt_id'] ?>">
        <h3><?= htmlspecialchars($p['nev']) ?></h3>
        <textarea class="leiras" data-projekt-nap-id="<?= $projekt_nap_id ?>"><?= htmlspecialchars($leiras) ?></textarea>
        
        <h4>Dolgozók:</h4>
        <div class="assigned dolgozok">
            <?php foreach($dolgozok as $d) echo "<div class='item'>" . htmlspecialchars($d['valodi_nev']) . "</div>"; ?>
        </div>
        <h4>Járművek:</h4>
        <div class="assigned jarmuvek">
            <?php foreach($jarmuvek as $j) echo "<div class='item'>" . htmlspecialchars($j['rendszam']) . "</div>"; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<script>
const datumInput = document.getElementById('datum');
datumInput.addEventListener('change', () => {
    const params = new URLSearchParams(window.location.search);
    if (params.has('lap')) {
        window.location.href = '?lap=nap_szervezes&datum=' + datumInput.value;
    } else {
        window.location.href = '?datum=' + datumInput.value;
    }
});

window.szabadsagIds = <?= json_encode(array_values($szabadsagolt_ids)) ?>;
window.szabadsagList = <?= json_encode($szabadsagolt_dolgozok) ?>;

function updateUnassigned(){
    const datum = datumInput.value;

    fetch('api.php?action=get_unassigned&datum=' + encodeURIComponent(datum))
        .then(res => res.json())
        .then(data => {
            const szabIds = (window.szabadsagIds || []).map(String);
            const dolgozokDiv = document.getElementById('dolgozok');
            const dolgozokTitle = (dolgozokDiv.querySelector('h3') || {}).textContent || 'Dolgozók';
            dolgozokDiv.innerHTML = '<h3>' + dolgozokTitle + '</h3>';
            (data.dolgozok || []).forEach(d => {
                if (szabIds.includes(String(d.id))) return;
                const el = document.createElement('div');
                el.className = 'item';
                el.textContent = d.valodi_nev;
                el.dataset.id = d.id;
                el.dataset.tipus = 'dolgozo';
                el.setAttribute('draggable', 'true');
                dolgozokDiv.appendChild(el);
            });

            const jarmuDiv = document.getElementById('jarmuvek');
            const jarmuTitle = (jarmuDiv.querySelector('h3') || {}).textContent || 'Járművek';
            jarmuDiv.innerHTML = '<h3>' + jarmuTitle + '</h3>';
            (data.jarmuvek || []).forEach(j => {
                const el = document.createElement('div');
                el.className = 'item';
                el.textContent = j.rendszam;
                el.dataset.id = j.id;
                el.dataset.tipus = 'jarmu';
                el.setAttribute('draggable', 'true');
                jarmuDiv.appendChild(el);
            });

            const szabDiv = document.getElementById('szabadsag');
            const szabTitle = (szabDiv.querySelector('h3') || {}).textContent || 'Szabadság';
            szabDiv.innerHTML = '<h3>' + szabTitle + '</h3>';
            (window.szabadsagList || []).forEach(s => {
                const el = document.createElement('div');
                el.className = 'item';
                el.textContent = s.valodi_nev;
                el.dataset.id = s.id;
                el.dataset.tipus = 'dolgozo';
                szabDiv.appendChild(el);
            });

            initDrag();
        })
        .catch(err => {
            console.error('updateUnassigned hiba:', err);
        });
}

function dragStart(e){
    if(!e.target || !e.target.dataset) return;
    e.dataTransfer.setData('application/json', JSON.stringify({
        id: e.target.dataset.id,
        tipus: e.target.dataset.tipus,
        nev: e.target.textContent
    }));
}

function initDrag(){
    document.querySelectorAll('.item').forEach(item => {
        try { item.removeEventListener('dragstart', dragStart); } catch(e){}

        if (item.getAttribute('draggable') === 'true') {
            item.addEventListener('dragstart', dragStart);
        }

        item.ondblclick = null;
        if (item.closest('.project')) {
            item.ondblclick = function(e) {
                const parentProj = item.closest('.project');
                if (!parentProj) return;
                const projekt_nap_id = parentProj.dataset.id;
                if (!projekt_nap_id) return;

                let tipus = parentProj.querySelector('.dolgozok').contains(item) ? 'dolgozo' : 'jarmu';
                fetch('api.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        action:'delete',
                        projekt_nap_id,
                        tipus,
                        nev: item.textContent
                    })
                })
                .then(r => r.json())
                .then(res => {
                    if(res.success){
                        item.remove();
                        updateUnassigned();
                    } else {
                        alert(res.error || 'Hiba történt!');
                    }
                })
                .catch(err => {
                    console.error('delete hiba:', err);
                    alert('Hálózati hiba történt.');
                });
            };
        }
    });

    document.querySelectorAll('.project').forEach(proj => {
        proj.ondragover = e => e.preventDefault();
        proj.ondrop = e => {
            e.preventDefault();
            let data;
            try {
                data = JSON.parse(e.dataTransfer.getData('application/json'));
            } catch (err) {
                console.error('Hibás dataTransfer:', err);
                return;
            }
            let projekt_nap_id = proj.dataset.id;
            const projekt_id = proj.dataset.projektId;

            fetch('api.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    projekt_nap_id,
                    projekt_id,
                    tipus: data.tipus,
                    id: data.id,
                    datum: '<?= $datum ?>'
                })
            })
            .then(r => r.json())
            .then(res => {
                if(res.projekt_nap_id){
                    proj.dataset.id = res.projekt_nap_id;
                }
                if(res.success || res.projekt_nap_id){
                    const targetDiv = proj.querySelector('.' + (data.tipus==='dolgozo' ? 'dolgozok' : 'jarmuvek'));
                    const d = document.createElement('div');
                    d.className = 'item';
                    d.textContent = data.nev;
                    targetDiv.appendChild(d);
                    initDrag();
                    updateUnassigned();
                } else {
                    alert(res.error || 'Hiba történt!');
                }
            })
            .catch(err => {
                console.error('Hozzárendelés hiba:', err);
                alert('Hálózati hiba történt.');
            });
        };
    });

    // Leírás mezők debounce-olt eseménykezelői
    const leirasTimers = {};
    document.querySelectorAll('textarea.leiras').forEach(textarea => {
        textarea.oninput = function() {
            const projekt_nap_id = textarea.dataset.projektNapId;
            if (!projekt_nap_id) return;

            clearTimeout(leirasTimers[projekt_nap_id]);
            leirasTimers[projekt_nap_id] = setTimeout(() => {
                fetch('api.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        action: 'update_leiras',
                        projekt_nap_id,
                        leiras: textarea.value
                    })
                })
                .then(r => r.json())
                .then(res => {
                    if(!res.success){
                        alert(res.error || 'Leírás mentése sikertelen!');
                    }
                })
                .catch(err => {
                    console.error('leiras mentes hiba:', err);
                    alert('Hálózati hiba történt.');
                });
            }, 1000); // 1 mp szünet után ment
        };
    });
}

initDrag();
updateUnassigned();
</script>

</body>
</html>
