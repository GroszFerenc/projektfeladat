<?php
require 'db.php';
$data = json_decode(file_get_contents('php://input'), true);

// Törlés
if(isset($data['action']) && $data['action'] == 'delete'){
    $projekt_nap_id = $data['projekt_nap_id'];
    $tipus = $data['tipus'];
    $nev = $data['nev'];

    if($tipus == 'dolgozo'){
        $stmt = $pdo->prepare("DELETE pd FROM projekt_nap_dolgozo pd
            JOIN dolgozok d ON pd.dolgozo_id=d.id
            WHERE pd.projekt_nap_id=? AND d.valodi_nev=?");
        $stmt->execute([$projekt_nap_id, $nev]);
    } elseif($tipus=='jarmu'){
        $stmt = $pdo->prepare("DELETE pa FROM projekt_nap_auto pa
            JOIN jarmu j ON pa.jarmu_id=j.id
            WHERE pa.projekt_nap_id=? AND j.rendszam=?");
        $stmt->execute([$projekt_nap_id, $nev]);
    }

    echo json_encode(['success'=>true]);
    exit;
}

// Lekérdezi a hozzárendelt dolgozókat/járműveket
if(isset($_GET['action']) && $_GET['action']=='get_assigned' && isset($_GET['projekt_nap_id'])){
    $projekt_nap_id = $_GET['projekt_nap_id'];
    $dolgozok = $pdo->prepare("
        SELECT d.valodi_nev 
        FROM dolgozok d 
        JOIN projekt_nap_dolgozo pd ON d.id=pd.dolgozo_id 
        WHERE pd.projekt_nap_id=?
    ");
    $dolgozok->execute([$projekt_nap_id]);

    $jarmuvek = $pdo->prepare("
        SELECT j.rendszam 
        FROM jarmu j 
        JOIN projekt_nap_auto pa ON j.id=pa.jarmu_id 
        WHERE pa.projekt_nap_id=?
    ");
    $jarmuvek->execute([$projekt_nap_id]);

    echo json_encode([
        'dolgozok'=>$dolgozok->fetchAll(PDO::FETCH_ASSOC),
        'jarmuvek'=>$jarmuvek->fetchAll(PDO::FETCH_ASSOC)
    ]);
    exit;
}

// Hozzárendelés drag and drop alapján
$projekt_nap_id = $data['projekt_nap_id'] ?? null;
$projekt_id = $data['projekt_id'] ?? null;
$tipus = $data['tipus'] ?? null;
$id = $data['id'] ?? null;
$datum = $data['datum'] ?? date('Y-m-d');

if(!$projekt_nap_id && $projekt_id){
    $stmt = $pdo->prepare("INSERT INTO projekt_napok (projekt_id, datum) VALUES (?, ?)");
    $stmt->execute([$projekt_id, $datum]);
    $projekt_nap_id = $pdo->lastInsertId();
    echo json_encode(['projekt_nap_id'=>$projekt_nap_id]);
    exit;
}

if($projekt_nap_id && $tipus && $id){
    if($tipus=='dolgozo'){
        $stmt = $pdo->prepare("INSERT IGNORE INTO projekt_nap_dolgozo (projekt_nap_id,dolgozo_id) VALUES (?,?)");
        $stmt->execute([$projekt_nap_id,$id]);
    } elseif($tipus=='jarmu'){
        $stmt = $pdo->prepare("INSERT IGNORE INTO projekt_nap_auto (projekt_nap_id,jarmu_id) VALUES (?,?)");
        $stmt->execute([$projekt_nap_id,$id]);
    }

    echo json_encode(['success'=>true, 'projekt_nap_id'=>$projekt_nap_id]);
    exit;
}

// Opció: ki nem osztott lista (frissítéshez)
if(isset($_GET['action']) && $_GET['action']=='get_unassigned' && isset($_GET['datum'])){
    $datum = $_GET['datum'];

    $stmtDolgozok = $pdo->prepare("
        SELECT id, valodi_nev FROM dolgozok
        WHERE id NOT IN (
            SELECT dolgozo_id 
            FROM projekt_nap_dolgozo 
            WHERE projekt_nap_id IN (
                SELECT id FROM projekt_napok WHERE datum=?
            )
        )
    ");
    $stmtDolgozok->execute([$datum]);
    $dolgozok = $stmtDolgozok->fetchAll(PDO::FETCH_ASSOC);

    $stmtJarmuvek = $pdo->prepare("
        SELECT id, rendszam FROM jarmu
        WHERE id NOT IN (
            SELECT jarmu_id 
            FROM projekt_nap_auto 
            WHERE projekt_nap_id IN (
                SELECT id FROM projekt_napok WHERE datum=?
            )
        )
    ");
    $stmtJarmuvek->execute([$datum]);
    $jarmuvek = $stmtJarmuvek->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['dolgozok'=>$dolgozok, 'jarmuvek'=>$jarmuvek]);
    exit;
}

// Leírás frissítése
if(isset($data['action']) && $data['action'] === 'update_leiras'){
    $projekt_nap_id = (int)($data['projekt_nap_id'] ?? 0);
    $leiras = $data['leiras'] ?? '';

    if($projekt_nap_id > 0){
        $stmt = $pdo->prepare("UPDATE projekt_napok SET leiras=? WHERE id=?");
        $ok = $stmt->execute([$leiras, $projekt_nap_id]);
        echo json_encode(['success'=>$ok]);
    } else {
        echo json_encode(['success'=>false, 'error'=>'Nincs érvényes projekt_nap_id']);
    }
    exit;
}
