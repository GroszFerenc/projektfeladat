<?php
// szabadsag_torles.php

session_start();
require_once "db.php";

// Ellenőrizzük, hogy a dolgozó be van-e jelentkezve
if (!isset($_SESSION['id'])) {
    $redirect = ($_SESSION['jogosultsag'] ?? 0) == 1 ? "admin.php?lap=szabadsag&status=hiba" : "dolgozo.php?lap=szabadsag&status=hiba";
    header("Location: $redirect");
    exit;
}

$dolgozo_id_session = $_SESSION['id'];

// Ellenőrizzük, hogy a GET paraméterek megvannak
if (!isset($_GET['id']) || !isset($_GET['dolgozo_id'])) {
    $redirect = ($_SESSION['jogosultsag'] ?? 0) == 1 ? "admin.php?lap=szabadsag&status=hiba" : "dolgozo.php?lap=szabadsag&status=hiba";
    header("Location: $redirect");
    exit;
}

$torles_id = (int)$_GET['id'];
$dolgozo_id_get = (int)$_GET['dolgozo_id'];

// Ellenőrizzük, hogy a session ID egyezik-e a dolgozó ID-vel
if ($dolgozo_id_session !== $dolgozo_id_get) {
    $redirect = ($_SESSION['jogosultsag'] ?? 0) == 1 ? "admin.php?lap=szabadsag&status=hiba" : "dolgozo.php?lap=szabadsag&status=hiba";
    header("Location: $redirect");
    exit;
}

// Törlés az adatbázisból
$stmt = $pdo->prepare("DELETE FROM szabadsag WHERE id = :id AND dolgozo_id = :dolgozo_id");
$stmt->execute(['id' => $torles_id, 'dolgozo_id' => $dolgozo_id_get]);

// Visszairányítás a szabadságok oldalra siker státusszal
$redirect = ($_SESSION['jogosultsag'] ?? 0) == 1 ? "admin.php?lap=szabadsag&status=ok" : "dolgozo.php?lap=szabadsag&status=ok";
header("Location: $redirect");
exit;
?>
