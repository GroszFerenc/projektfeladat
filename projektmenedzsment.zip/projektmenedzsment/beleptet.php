<?php
session_start();
require_once "db.php"; // itt kapjuk a PDO kapcsolatot ($pdo)

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = trim($_POST['felh_nev']);
    $pass = trim($_POST['jelszo']);

    $sql = "SELECT id, felh_nev, valodi_nev, jelszo, jogosultsag 
            FROM dolgozok 
            WHERE felh_nev = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user]);
    $row = $stmt->fetch();

    if ($row) {
        if (password_verify($pass, $row['jelszo'])) {
            $_SESSION['id'] = $row['id'];
            $_SESSION['felh_nev'] = $row['felh_nev'];
            $_SESSION['valodi_nev'] = $row['valodi_nev'];
            $_SESSION['jogosultsag'] = $row['jogosultsag'];

            if ($row['jogosultsag'] == 1) {
                header("Location: admin.php");
            } else {
                header("Location: dolgozo.php");
            }
            exit;
        }
    }

    // Hibás felhasználónév/jelszó
    $error = urlencode("Hibás felhasználónév vagy jelszó!");
    header("Location: index.php?error=$error");
    exit;
} else {
    header("Location: index.php");
    exit;
}
?>
