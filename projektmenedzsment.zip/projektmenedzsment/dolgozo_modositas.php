<?php
require_once "adatbazis.php";

// Jogosultság ellenőrzése
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] != 1) {
    header("Location: index.php");
    exit;
}

// GET-ből az ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Hibás dolgozó azonosító!");
}

$modositando_id = (int)$_GET['id'];

// Dolgozó adatainak lekérése
$stmt = $conn->prepare("SELECT felh_nev, valodi_nev, jogosultsag FROM dolgozok WHERE id = ?");
$stmt->execute([$modositando_id]);
$dolgozo = $stmt->fetch();

if (!$dolgozo) {
    die("A dolgozó nem található!");
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Dolgozó módosítása</title>
</head>
<body>
    <h2>Dolgozó módosítása</h2>

    <form action="dolgozo_atiras.php?id=<?= $modositando_id ?>" method="post">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($modositando_id); ?>">

        <div>
            <label for="felh_nev">Felhasználónév:</label>
            <input type="text" name="felh_nev" id="felh_nev" value="<?php echo htmlspecialchars($dolgozo['felh_nev']); ?>" required>
        </div>

        <div>
            <label for="valodi_nev">Valódi név:</label>
            <input type="text" name="valodi_nev" id="valodi_nev" value="<?php echo htmlspecialchars($dolgozo['valodi_nev']); ?>" required>
        </div>

        <div>
            <label for="jogosultsag">Jogosultság:</label>
            <select name="jogosultsag" id="jogosultsag">
                <option value="1" <?php echo $dolgozo['jogosultsag'] == 1 ? 'selected' : ''; ?>>Adminisztrator</option>
                <option value="2" <?php echo $dolgozo['jogosultsag'] == 2 ? 'selected' : ''; ?>>Szakember</option> 
                <option value="3" <?php echo $dolgozo['jogosultsag'] == 3 ? 'selected' : ''; ?>>Segédmunkás</option>          </select>
        </div>

        <div>
            <button type="submit">Mentés</button>
        </div>
    </form>

    <p><a href="admin.php?lap=dolgozok">Vissza</a></p>
</body>
</html>
