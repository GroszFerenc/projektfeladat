<?php
// jarmu_atir.php
session_start();
require 'adatbazis.php'; // itt legyen a $conn kapcsolat

// Jogosultság ellenőrzése (csak Admin, azaz jogosultsag=1)
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] != 1) {
    header('Location: index.php');
    exit;
}

// Ellenőrzés, hogy POST-ban érkeztek-e a szükséges adatok
if (!isset($_POST['id'], $_POST['rendszam'], $_POST['uzemanyag']) || !is_numeric($_POST['id'])) {
    header('Location: admin.php?lap=jarmuvek&status=hiba');
    exit;
}

$id = (int)$_POST['id'];
$rendszam = trim($_POST['rendszam']);
$uzemanyag = trim($_POST['uzemanyag']);

try {
    $sql = "UPDATE jarmu SET rendszam = :rendszam, uzemanyag = :uzemanyag WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':rendszam', $rendszam, PDO::PARAM_STR);
    $stmt->bindParam(':uzemanyag', $uzemanyag, PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    header('Location: admin.php?lap=jarmuvek&status=ok');
    exit;
} catch (PDOException $e) {
    header('Location: admin.php?lap=jarmuvek&status=hiba');
    exit;
}
?>
