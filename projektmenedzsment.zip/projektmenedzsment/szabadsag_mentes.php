<?php
session_start();
include 'db.php'; // PDO $pdo kapcsolat

// Ellenőrizzük a sessiont
if (!isset($_SESSION['id'])) {
    $redirect = ($_SESSION['jogosultsag'] ?? 0) == 1 ? "admin.php?lap=szabadsagok&status=hiba" : "dolgozo.php?lap=szabadsagok&status=hiba";
    header("Location: $redirect");
    exit;
}

// POST adatok ellenőrzése
$dolgozo_id = $_POST['dolgozo_id'] ?? 0;
$kezdo_nap = $_POST['kezdo_nap'] ?? '';
$napok_szama = intval($_POST['napok_szama'] ?? 0);

// Session ID ellenőrzése a form-ból jövő ID-val
if ($dolgozo_id != $_SESSION['id'] || empty($kezdo_nap) || $napok_szama < 1) {
    $redirect = ($_SESSION['jogosultsag'] ?? 0) == 1 ? "admin.php?lap=szabadsag&status=hiba" : "dolgozo.php?lap=szabadsag&status=hiba";
    header("Location: $redirect");
    exit;
}

// Dátumok generálása
$datum = new DateTime($kezdo_nap);

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("INSERT INTO szabadsag (dolgozo_id, nap) VALUES (:dolgozo_id, :nap)");

    for ($i = 0; $i < $napok_szama; $i++) {
        $stmt->execute([
            ':dolgozo_id' => $dolgozo_id,
            ':nap' => $datum->format('Y-m-d')
        ]);
        $datum->modify('+1 day'); // Következő nap
    }

    $pdo->commit();
    
    $redirect = ($_SESSION['jogosultsag'] ?? 0) == 1 ? "admin.php?lap=szabadsag&status=ok" : "dolgozo.php?lap=szabadsag&status=ok";
    header("Location: $redirect");
    exit;
} catch (Exception $e) {
    $pdo->rollBack();
    $redirect = ($_SESSION['jogosultsag'] ?? 0) == 1 ? "admin.php?lap=szabadsag&status=hiba" : "dolgozo.php?lap=szabadsag&status=hiba";
    header("Location: $redirect");
    exit;
}

