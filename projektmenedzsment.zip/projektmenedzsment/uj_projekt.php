<?php
// uj_projekt.php

require 'adatbazis.php';

// Ellenőrzés: csak Admin (1) és Szakember (2) hozzáférhet
if (!isset($_SESSION['jogosultsag']) || !in_array($_SESSION['jogosultsag'], [1,2])) {
    echo "<p style='color:red;'>Nincs jogosultságod új projekt felvételére!</p>";
    exit;
}

// Alapértelmezett értékek az űrlaphoz
$projekt = [
    'nev' => '',
    'kezdet' => date('Y-m-d'),
    'leiras' => ''
];
?>

<div>
    <h1>Új projekt felvétele</h1>
    <form action="projekt_felvetel.php" method="post">
        <label>
            Név:<br>
            <input type="text" name="nev" value="<?= htmlspecialchars($projekt['nev']) ?>" required>
        </label><br><br>

        <label>
            Kezdete:<br>
            <input type="date" name="kezdet" value="<?= htmlspecialchars($projekt['kezdet']) ?>" required>
        </label><br><br>

        <label>
            Leírás:<br>
            <textarea name="leiras" rows="4" cols="50"><?= htmlspecialchars($projekt['leiras']) ?></textarea>
        </label><br><br>

        <button type="submit">Mentés</button>
        <a href="admin.php?lap=projektek">Mégse</a>
    </form>
</div>
