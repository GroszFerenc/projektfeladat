<?php
// jarmu_torles.php
session_start();
require 'adatbazis.php'; // itt legyen a $conn kapcsolat

// Jogosultság ellenőrzése (csak Admin, azaz jogosultsag=1)
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] != 1) {
    header('Location: index.php');
    exit;
}

// Ellenőrzés, hogy GET-ben érkezett-e az id
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: admin.php?lap=jarmuvek&status=hiba');
    exit;
}

$id = (int)$_GET['id'];

try {
    // Törlés az adatbázisból
    $sql = "DELETE FROM jarmu WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    // Sikeres törlés után visszairányítás a jarmuvek.php-hez
    header('Location: admin.php?lap=jarmuvek&status=ok');
    exit;
} catch (PDOException $e) {
    // Hiba esetén visszairányítás
    header('Location: admin.php?lap=jarmuvek&status=hiba');
    exit;
}
