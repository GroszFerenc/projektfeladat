<?php
// index.php
session_start();
session_destroy(); // Ha kijelentkezés, a session törlése

$error = '';
if (isset($_GET['error'])) {
    $error = htmlspecialchars($_GET['error']);
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bejelentkezés</title>
<style>
    /* Alap stílusok */
    body {
        font-family: Arial, sans-serif;
        background: linear-gradient(135deg, #6a11cb, #2575fc);
        color: #333;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .login-container {
        background: white;
        padding: 2rem;
        border-radius: 12px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        width: 100%;
        max-width: 400px;
        text-align: center;
    }

    h2 {
        margin-bottom: 1.5rem;
        color: #333;
    }

    input[type="text"], input[type="password"] {
        width: 100%;
        padding: 0.75rem;
        margin: 0.5rem 0 1rem 0;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 1rem;
    }

    input[type="submit"] {
        width: 100%;
        padding: 0.75rem;
        border: none;
        border-radius: 8px;
        background-color: #2575fc;
        color: white;
        font-size: 1rem;
        cursor: pointer;
        transition: background 0.3s;
    }

    input[type="submit"]:hover {
        background-color: #6a11cb;
    }

    .error {
        color: red;
        margin-bottom: 1rem;
    }

    @media (max-width: 480px) {
        .login-container {
            padding: 1.5rem;
        }
    }
</style>
</head>
<body>
<div class="login-container">
    <h2>Bejelentkezés</h2>
    <?php if (!empty($error)) echo "<div class='error'>$error</div>"; ?>
    <form action="beleptet.php" method="post">
        <input type="text" name="felh_nev" placeholder="Felhasználónév" required>
        <input type="password" name="jelszo" placeholder="Jelszó" required>
        <input type="submit" value="Belépés">
    </form>
</div>
</body>
</html>
