<?php
require_once "adatbazis.php";

// Be van-e jelentkezve?
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit;
}

// A módosítandó ID GET-ből
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Hibás dolgozó azonosító!");
}

$modositando_id = (int)$_GET['id'];
$sajat_id = (int)$_SESSION['id'];
$jogosultsag = isset($_SESSION['jogosultsag']) ? (int)$_SESSION['jogosultsag'] : 0;

// Ellenőrzés: ha nem a saját ID-t akarja módosítani és nem admin, akkor hiba
if ($modositando_id !== $sajat_id && $jogosultsag !== 1) {
    die("Nincs jogosultságod más felhasználó jelszavát módosítani!");
}

// Űrlap előkészítés
$ker_sajat = ($modositando_id === $sajat_id);
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Jelszó módosítása</title>
</head>
<body>
    <h2>Jelszó módosítása</h2>

    <form action="jelszo_atir.php" method="post">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($modositando_id); ?>">

        <?php if ($ker_sajat): ?>
            <div>
                <label for="regi_jelszo">Régi jelszó:</label>
                <input type="password" name="regi_jelszo" id="regi_jelszo" required>
            </div>
        <?php endif; ?>

        <div>
            <label for="uj_jelszo">Új jelszó:</label>
            <input type="password" name="uj_jelszo" id="uj_jelszo" required>
        </div>

        <div>
            <label for="uj_jelszo2">Új jelszó ismét:</label>
            <input type="password" name="uj_jelszo2" id="uj_jelszo2" required>
        </div>

        <div>
            <button type="submit">Mentés</button>
        </div>
    </form>

    <p><a href="admin.php?lap=dolgozok">Vissza</a></p>
</body>
</html>
