<?php
// uj_szabadsag.php

// A dolgozó ID-jét a session-ből vesszük
$dolgozo_id = $_SESSION['id'] ?? 0;

// Alapértékek
$alap_kezdo_nap = date("Y-m-d");
$alap_napok_szama = 1;
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Új szabadság felvétele</title>
    <style>
        form { max-width: 400px; margin: 20px auto; }
        label { display: block; margin-top: 10px; }
        input[type="date"], input[type="number"] { width: 100%; padding: 5px; }
        input[type="submit"] { margin-top: 15px; padding: 8px 12px; }
    </style>
</head>
<body>
    <h2>Új szabadság felvétele</h2>
    <form action="szabadsag_mentes.php" method="post">
        <input type="hidden" name="dolgozo_id" value="<?= $dolgozo_id ?>">
        
        <label for="kezdo_nap">Kezdő nap:</label>
        <input type="date" id="kezdo_nap" name="kezdo_nap" value="<?= $alap_kezdo_nap ?>" required>
        
        <label for="napok_szama">Napok száma:</label>
        <input type="number" id="napok_szama" name="napok_szama" min="1" value="<?= $alap_napok_szama ?>" required>
        
        <input type="submit" value="Mentés">
    </form>
    <?php
    // Új szabadság felvétele link jogosultságtól függően
    $link = ($_SESSION['jogosultsag'] ?? 0) == 1 ? "admin.php?lap=szabadsag" : "dolgozo.php?lap=szabadsag";
    ?>
    <p><a href="<?= $link ?>">Vissza a szabadságokhoz</a></p>
</body>
</html>
