<?php

if (!isset($_SESSION['id']) || $_SESSION['id'] != 1) {
    echo "Hozzáférés megtagadva!";
    exit;
}

require 'db.php';

$projekt_id = $_POST['projekt_id'] ?? null;

// Projektek listája
$projektek_stmt = $pdo->query("SELECT id, nev FROM projektek ORDER BY nev");
$projektek = $projektek_stmt->fetchAll(PDO::FETCH_ASSOC);

// Ha kiválasztott projekt
$projekt = null;
$projekt_napok = [];
$osszes_dolgozoi_munkanap = 0;
$osszes_jarmu = 0;
$napok_szama = 0;

if ($projekt_id) {
    // Projekt adatai
    $stmt = $pdo->prepare("SELECT * FROM projektek WHERE id=?");
    $stmt->execute([$projekt_id]);
    $projekt = $stmt->fetch(PDO::FETCH_ASSOC);

    // Projekt napok
    $stmtNapok = $pdo->prepare("SELECT id, datum, leiras FROM projekt_napok WHERE projekt_id=? ORDER BY datum");
    $stmtNapok->execute([$projekt_id]);
    $projekt_napok = $stmtNapok->fetchAll(PDO::FETCH_ASSOC);

    $dolgozoi_munkanapok = 0;
    $jarmu_munkanapok = 0;

    foreach ($projekt_napok as &$nap) {
        // Dolgozók száma
        $stmtDolgozok = $pdo->prepare("SELECT COUNT(*) as cnt FROM projekt_nap_dolgozo WHERE projekt_nap_id=?");
        $stmtDolgozok->execute([$nap['id']]);
        $nap['dolgozok'] = $stmtDolgozok->fetch(PDO::FETCH_ASSOC)['cnt'];

        // Járművek száma
        $stmtJarmuvek = $pdo->prepare("SELECT COUNT(*) as cnt FROM projekt_nap_auto WHERE projekt_nap_id=?");
        $stmtJarmuvek->execute([$nap['id']]);
        $nap['jarmuvek'] = $stmtJarmuvek->fetch(PDO::FETCH_ASSOC)['cnt'];

        // Dolgozói munkanapok
        $stmtDolgozokList = $pdo->prepare("SELECT dolgozo_id FROM projekt_nap_dolgozo WHERE projekt_nap_id=?");
        $stmtDolgozokList->execute([$nap['id']]);
        $dolgozok_ids = $stmtDolgozokList->fetchAll(PDO::FETCH_COLUMN);

        $dolgozoi_munkanapok += count($dolgozok_ids);

        // Járműhasználat
        $stmtJarmuList = $pdo->prepare("SELECT jarmu_id FROM projekt_nap_auto WHERE projekt_nap_id=?");
        $stmtJarmuList->execute([$nap['id']]);
        $jarmu_ids = $stmtJarmuList->fetchAll(PDO::FETCH_COLUMN);
        $jarmu_munkanapok += count($jarmu_ids);
    }
    unset($nap);

    $napok_szama = count($projekt_napok);
    $osszes_dolgozoi_munkanap = $dolgozoi_munkanapok;
    $osszes_jarmu = $jarmu_munkanapok;
}
?>



<h2>Projekt lekérdezés</h2>

<form method="post">
    <label for="projekt_id">Válassz projektet:</label>
    <select name="projekt_id" id="projekt_id" onchange="this.form.submit()">
        <option value="">-- Válassz --</option>
        <?php foreach($projektek as $p): ?>
            <option value="<?= $p['id'] ?>" <?= ($projekt_id == $p['id'] ? 'selected' : '') ?>>
                <?= htmlspecialchars($p['nev']) ?>
            </option>
        <?php endforeach; ?>
    </select>
</form>

<?php if ($projekt): ?>
    <h3>Projekt adatai:</h3>
    <p><strong>Név:</strong> <?= htmlspecialchars($projekt['nev']) ?></p>
    <p><strong>Kezdet:</strong> <?= $projekt['kezdet'] ?></p>
    <p><strong>Vég:</strong> <?= $projekt['veg'] ?? '-' ?></p>
    <p><strong>Leírás:</strong> <?= nl2br(htmlspecialchars($projekt['leiras'])) ?></p>

    <h3>Projekt napok:</h3>
    <table>
        <thead>
            <tr>
                <th>Dátum</th>
                <th>Dolgozók száma</th>
                <th>Járművek száma</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($projekt_napok as $nap): ?>
                <tr>
                    <td><?= $nap['datum'] ?></td>
                    <td><?= $nap['dolgozok'] ?></td>
                    <td><?= $nap['jarmuvek'] ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="summary">
        Összes nap: <?= $napok_szama ?> <br>
        Összes dolgozói munkanap: <?= $osszes_dolgozoi_munkanap ?> <br>
        Összes dolgozói jármű: <?= $osszes_jarmu ?>
    </div>
<?php endif; ?>


</html>
