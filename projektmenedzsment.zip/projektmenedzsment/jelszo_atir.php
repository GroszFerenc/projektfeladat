<?php
session_start();
require 'adatbazis.php';

// Be van-e jelentkezve?
if (!isset($_SESSION['id'])) {
    header('Location: index.php');
    exit;
}

// POST-ból az ID
$modositando_id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$sajat_id = $_SESSION['id'];
$jogosultsag = $_SESSION['jogosultsag'] ?? 0;

// Jogosultság ellenőrzése
if ($modositando_id !== $sajat_id && $jogosultsag != 1) {
    // Nem jogosult
    $redirect = ($jogosultsag == 1) ? "admin.php?lap=dolgozok&statusz=hiba" : "dolgozo.php?statusz=hiba";
    header("Location: $redirect");
    exit;
}

// Adatok átvétele
$regi_jelszo = $_POST['regi_jelszo'] ?? '';
$uj_jelszo = $_POST['uj_jelszo'] ?? '';
$uj_jelszo_ujra = $_POST['uj_jelszo2'] ?? '';

// Új jelszavak ellenőrzése
if (empty($uj_jelszo) || empty($uj_jelszo_ujra) || $uj_jelszo !== $uj_jelszo_ujra) {
    $redirect = ($jogosultsag == 1) ? "admin.php?lap=dolgozok&statusz=hiba" : "dolgozo.php?statusz=hiba";
    header("Location: $redirect");
    exit;
}

// Ha a saját jelszót módosítja → régi jelszó ellenőrzése
if ($modositando_id === $sajat_id) {
    if (empty($regi_jelszo)) {
        header("Location: dolgozo.php?statusz=hiba");
        exit;
    }

    $stmt = $conn->prepare("SELECT jelszo FROM dolgozok WHERE id = ?");
    $stmt->execute([$modositando_id]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($regi_jelszo, $user['jelszo'])) {
        $redirect = ($jogosultsag == 1) ? "admin.php?lap=dolgozok&statusz=hiba" : "dolgozo.php?statusz=hiba";
        header("Location: $redirect");
        exit;
    }
}

// Új jelszó hashelése
$uj_jelszo_hash = password_hash($uj_jelszo, PASSWORD_DEFAULT);

// Adatbázis frissítése
$stmt = $conn->prepare("UPDATE dolgozok SET jelszo = ? WHERE id = ?");
if ($stmt->execute([$uj_jelszo_hash, $modositando_id])) {
    // Sikeres módosítás
    $redirect = ($jogosultsag == 1) ? "admin.php?lap=dolgozok&statusz=ok" : "dolgozo.php?statusz=ok";
} else {
    // Hiba az adatbázis frissítésnél
    $redirect = ($jogosultsag == 1) ? "admin.php?lap=dolgozok&statusz=hiba" : "dolgozo.php?statusz=hiba";
}

header("Location: $redirect");
exit;
?>
