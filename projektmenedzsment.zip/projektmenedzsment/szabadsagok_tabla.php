<?php
// szabadsagok_tabla.php

require_once "db.php"; // itt lesz elérhető a $pdo változó

// Dolgozó ID a session-ből
$dolgozo_id = $_SESSION['id'] ?? 0; // ha nincs session, alapértelmezett 0

// Szabadságok lekérdezése
$stmt = $pdo->prepare("SELECT id, nap FROM szabadsag WHERE dolgozo_id = :dolgozo_id ORDER BY nap DESC");
$stmt->execute(['dolgozo_id' => $dolgozo_id]);
$szabadsagok = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Szabadságok</title>
    <style>
        table { border-collapse: collapse; width: 50%; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
        th { background-color: #f4f4f4; }
        a { text-decoration: none; color: blue; }
        a:hover { text-decoration: underline; }
        .torles-btn { color: red; }
    </style>
</head>
<body>
    <h2>Szabadságok</h2>
    <table>
        <tr>
            <th>Dátum</th>
            <th>Művelet</th>
        </tr>
        <?php foreach ($szabadsagok as $sz): ?>
        <tr>
            <td><?= htmlspecialchars($sz['nap']) ?></td>
            <td>
                <a class="torles-btn" 
                   href="szabadsag_torles.php?id=<?= $sz['id'] ?>&dolgozo_id=<?= $dolgozo_id ?>" 
                   onclick="return confirm('Biztos törölni akarod?')">
                   Törlés
                </a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <?php
    // Új szabadság felvétele link jogosultságtól függően
    $link = ($_SESSION['jogosultsag'] ?? 0) == 1 ? "admin.php?lap=uj_szabadsag" : "dolgozo.php?lap=uj_szabadsag";
    ?>
    <p><a href="<?= $link ?>">Új szabadság felvétele</a></p>
</body>
</html>
