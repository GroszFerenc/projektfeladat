<?php
// jarmu_hozzaad.php
session_start();
require 'adatbazis.php'; // itt legyen a $conn kapcsolat

// Jogosultság ellenőrzése (csak Admin, azaz jogosultsag=1)
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] != 1) {
    header('Location: index.php');
    exit;
}

// Ellenőrzés, hogy POST adatok érkeztek-e
if (!isset($_POST['rendszam']) || !isset($_POST['uzemanyag'])) {
    header('Location: uj_jarmu.php?status=hiba');
    exit;
}

// POST adatok tisztítása
$rendszam = trim($_POST['rendszam']);
$uzemanyag = trim($_POST['uzemanyag']);

// Egyszerű validáció
if ($rendszam === '' || $uzemanyag === '') {
    header('Location: uj_jarmu.php?status=hiba');
    exit;
}

try {
    // Beszúrás az adatbázisba
    $sql = "INSERT INTO jarmu (rendszam, uzemanyag) VALUES (:rendszam, :uzemanyag)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':rendszam', $rendszam);
    $stmt->bindParam(':uzemanyag', $uzemanyag);
    $stmt->execute();

    // Sikeres beszúrás után visszairányítás a jarmuvek.php-hez, státusz jelzéssel
    header('Location: admin.php?lap=jarmuvek&status=ok');
    exit;
} catch (PDOException $e) {
    // Hiba esetén visszairányítás az űrlapra
    header('Location: admin.php?lap=jarmuvek&status=hiba');
    exit;
}
