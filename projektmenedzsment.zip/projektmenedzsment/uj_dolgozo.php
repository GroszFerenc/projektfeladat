<?php
// Adatbázis kapcsolat
require_once __DIR__ . "/db.php"; // $pdo elérhető lesz

$hiba = "";
$siker = "";

// Űrlap feldolgozása
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $felh_nev   = trim($_POST['felh_nev'] ?? "");
    $valodi_nev = trim($_POST['valodi_nev'] ?? "");
    $jelszo     = $_POST['jelszo'] ?? "";
    $jelszo_ujra = $_POST['jelszo_ujra'] ?? "";
    $jogosultsag = $_POST['jogosultsag'] ?? "";

    // Validáció
    if (!$felh_nev || !$valodi_nev || !$jelszo || !$jelszo_ujra || !$jogosultsag) {
        $hiba = "Minden mezőt ki kell tölteni!";
    } elseif ($jelszo !== $jelszo_ujra) {
        $hiba = "A jelszavak nem egyeznek!";
    } else {
        // Jelszó hash-elése
        $jelszo_hash = password_hash($jelszo, PASSWORD_DEFAULT);

        // Jogosultság számértéke
        switch ($jogosultsag) {
            case 'adminisztrator': $jog_szam = 1; break;
            case 'szakember': $jog_szam = 2; break;
            case 'segédmunkas': $jog_szam = 3; break;
            default: $jog_szam = 3; break;
        }

        try {
            // Beszúrás az adatbázisba
            $stmt = $pdo->prepare("INSERT INTO dolgozok (felh_nev, valodi_nev, jelszo, jogosultsag) 
                                   VALUES (:felh_nev, :valodi_nev, :jelszo, :jogosultsag)");
            $stmt->execute([
                ':felh_nev'   => $felh_nev,
                ':valodi_nev' => $valodi_nev,
                ':jelszo'     => $jelszo_hash,
                ':jogosultsag'=> $jog_szam
            ]);

            header("Location: admin.php?lap=dolgozok");
            exit;
        } catch (PDOException $e) {
            $hiba = "Hiba az adatbázisba íráskor: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Új dolgozó felvétele</title>
</head>
<body>
    <h1>Új dolgozó felvétele</h1>

    <?php if ($hiba) echo "<p style='color:red;'>$hiba</p>"; ?>
    <?php if ($siker) echo "<p style='color:green;'>$siker</p>"; ?>

    <form method="post">
        <label>Felhasználónév: <input type="text" name="felh_nev" required></label><br><br>
        <label>Valódi név: <input type="text" name="valodi_nev" required></label><br><br>
        <label>Jelszó: <input type="password" name="jelszo" required></label><br><br>
        <label>Jelszó újra: <input type="password" name="jelszo_ujra" required></label><br><br>
        <label>Jogosultság:
            <select name="jogosultsag" required>
                <option value="adminisztrator">Adminisztrátor</option>
                <option value="szakember">Szakember</option>
                <option value="segédmunkas">Segédmunkás</option>
            </select>
        </label><br><br>
        <button type="submit">Mentés</button>
    </form>
</body>
</html>
