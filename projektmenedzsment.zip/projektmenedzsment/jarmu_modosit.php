<?php
// jarmu_modosit.php

require 'adatbazis.php'; // itt legyen a $conn kapcsolat

// Jogosultság ellenőrzése (csak Admin, azaz jogosultsag=1)
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] != 1) {
    header('Location: index.php?error=Nincs+hozzá+jogosultságod!');
    exit;
}

// Ellenőrzés, hogy GET-ben érkezett-e az id
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: admin.php?lap=jarmuvek&status=hiba');
    exit;
}

$id = (int)$_GET['id'];

// Jármű adatainak lekérése az adatbázisból
try {
    $sql = "SELECT id, rendszam, uzemanyag FROM jarmu WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $jarmu = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$jarmu) {
        // Ha nincs ilyen jármű
        header('Location: admin.php?lap=jarmuvek&status=hiba');
        exit;
    }
} catch (PDOException $e) {
    header('Location: admin.php?lap=jarmuvek&status=hiba');
    exit;
}
?>

<div>
    <h1>Jármű módosítása</h1>
    <form method="post" action="jarmu_atir.php">
        <input type="hidden" name="id" value="<?= htmlspecialchars($jarmu['id']) ?>">
        <label for="rendszam">Rendszám:</label><br>
        <input type="text" name="rendszam" id="rendszam" value="<?= htmlspecialchars($jarmu['rendszam']) ?>" required><br><br>

        <label for="uzemanyag">Üzemanyag:</label><br>
        <input type="text" name="uzemanyag" id="uzemanyag" value="<?= htmlspecialchars($jarmu['uzemanyag']) ?>" required><br><br>

        <button type="submit">Mentés</button>
    </form>
</div>
