<?php
// projekt_modosit.php
require 'adatbazis.php';


// Jogosultság ellenőrzés
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] != 1) {
    header('Location: index.php');
    exit;
}

// Projekt ID lekérése GET-ből
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: admin.php?lap=projektek&status=hiba');
    exit;
}
$projektId = (int)$_GET['id'];

// Projekt adatainak lekérdezése
$sql = "SELECT id, nev, leiras, kezdet, veg FROM projektek WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $projektId]);
$projekt = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$projekt) {
    header('Location: admin.php?lap=projektek&status=hiba');
    exit;
}

// Statusz üzenet
$statuszUzenet = '';
if (isset($_GET['status'])) {
    if ($_GET['status'] === 'ok') {
        $statuszUzenet = "A módosítás sikeresen megtörtént.";
    } elseif ($_GET['status'] === 'hiba') {
        $statuszUzenet = "Hiba történt a mentés során!";
    }
}
?>

<div>
    <h1>Projekt módosítása</h1>
    <?php if ($statuszUzenet): ?>
        <p style="color: green; font-weight: bold;"><?= htmlspecialchars($statuszUzenet) ?></p>
    <?php endif; ?>
</div>

<form method="post" action="projekt_atir.php">
    <input type="hidden" name="id" value="<?= $projekt['id'] ?>">

    <label>Projekt neve:</label><br>
    <input type="text" name="nev" value="<?= htmlspecialchars($projekt['nev']) ?>" required><br><br>

    <label>Leírás:</label><br>
    <textarea name="leiras" rows="4"><?= htmlspecialchars($projekt['leiras']) ?></textarea><br><br>

    <label>Kezdete:</label><br>
    <input type="date" name="kezdet" value="<?= htmlspecialchars($projekt['kezdet']) ?>" required><br><br>

    <!-- A vége mezőt nem jelenítjük meg, mert csak lezáráskor töltjük ki -->

    <button type="submit">Mentés</button>
</form>

<div>
    <a href="admin.php?lap=projektek">Vissza a projektekhez</a>
</div>
