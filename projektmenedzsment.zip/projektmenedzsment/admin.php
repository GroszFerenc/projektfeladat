<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

$lap = $_GET['lap'] ?? 'naptar';
?>

<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Admin Felület</title>
<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    display: flex;
    flex-direction: row;
}

/* Sidebar alapbeállítás */
.sidebar {
    width: 220px;
    background-color: #2c3e50;
    color: #ecf0f1;
    height: 100vh;
    display: flex;
    flex-direction: column;
}
.sidebar h2 {
    text-align: center;
    padding: 1em 0;
    border-bottom: 1px solid #34495e;
}
.sidebar a {
    color: #ecf0f1; /* alap szín */
    text-decoration: none;
    padding: 12px 20px;
    display: block;
}
.sidebar a:hover {
    background-color: #34495e;
}

/* Tartalom */
.content {
    flex: 1;
    padding: 20px;
}

/* Táblázatok */
table {
    border-collapse: collapse;
    width: 100%;
}
table, th, td {
    border: 1px solid #ccc;
}
th, td {
    padding: 8px;
    text-align: left;
}
button {
    margin-right: 5px;
}

/* Naptár */
.calendar {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 5px;
}
.calendar div {
    padding: 10px;
    border: 1px solid #ccc;
    text-align: center;
}
.today {
    background-color: #3498db;
    color: #fff;
}

/* --- Mobil menü --- */
.mobile-menu-btn {
    display: none;
    padding: 12px;
    cursor: pointer;
    background-color: #2c3e50;
    color: #ecf0f1;
    font-size: 20px;
    text-align: center;
}
.mobile-menu {
    display: none;
    flex-direction: column;
    background-color: #34495e;
}
.mobile-menu.show {
    display: flex;
}
.mobile-menu a {
    padding: 12px 20px;
    border-top: 1px solid #2c3e50;
    color: #ecf0f1; /* sidebar alap szín */
    text-decoration: none;
}
.mobile-menu a:hover {
    background-color: #2c3e50;
}

/* Responsive */
@media (max-width: 768px) {
    body {
        flex-direction: column;
    }
    .sidebar {
        display: none;
    }
    .mobile-menu-btn {
        display: block;
    }
}
</style>
</head>
<body>

<!-- Mobil menü gomb -->
<span class="mobile-menu-btn" onclick="toggleMenu()">☰ Menü</span>
<div class="mobile-menu" id="mobileMenu">
    <a href="?lap=default">Naptár</a>
    <a href="?lap=dolgozok">Dolgozók</a>
    <a href="?lap=projektek">Projektek</a>
    <a href="?lap=nap_szervezes">Nap szervezes</a>
    <a href="?lap=beosztas">Beosztas</a>
    <a href="?lap=jarmuvek">Járművek</a>
    <a href="?lap=szabadsag">Szabadság</a>
    <a href="?lap=lekerdezesek">Lekérdezések</a>
    <a href="index.php">Kijelentkezés</a>
</div>

<div class="sidebar">
    <h2><?php echo htmlspecialchars($_SESSION['valodi_nev']); ?></h2>
    <a href="?lap=default">Naptár</a>
    <a href="?lap=dolgozok">Dolgozók</a>
    <a href="?lap=projektek">Projektek</a>
    <a href="?lap=nap_szervezes">Nap szervezes</a>
    <a href="?lap=beosztas">Beosztas</a>
    <a href="?lap=jarmuvek">Járművek</a>
    <a href="?lap=szabadsag">Szabadság</a>
    <a href="?lap=lekerdezesek">Lekérdezések</a>
    <a href="index.php">Kijelentkezés</a>
</div>

<div class="content">
<?php
switch($lap) {
    case 'dolgozok':
        include 'dolgozok_tabla.php';
        break;
    case 'uj_dolgozo':
        include 'uj_dolgozo.php';
        break;
    case 'jelszo_modosit':
        include 'jelszo_modositas.php';
        break;
    case 'modosit':
        include 'dolgozo_modositas.php';
        break;
    case 'projektek':
        include 'projekt_tabla.php';
        break;
    case 'uj_projekt':
        include 'uj_projekt.php';
        break;
    case 'projekt_modosit':
        include 'projekt_modosit.php';
        break;
    case 'projekt_lezaras':
        include 'projekt_lezaras.php';
        break;
    case 'nap_szervezes':
        include 'nap_szervezes.php';
        break;
    case 'jarmuvek':
        include 'jarmu_tabla.php';
        break;
    case 'uj_jarmu':
        include 'uj_jarmu.php';
        break;
    case 'jarmu_modosit':
        include 'jarmu_modosit.php';
        break;
    case 'beosztas':
        include 'beosztas_tabla.php';
        break;
    case 'szabadsag':
        include 'szabadsagok_tabla.php';
        break;
    case 'uj_szabadsag':
        include 'uj_szabadsag.php';
        break;
    case 'lekerdezesek':
        include 'lekerdezes.php';
        break;
    case 'naptar':
    default:
    ?>
    <h1>Naptár</h1>
    <h2 id="monthTitle" style="text-align:center; margin-bottom:15px;"></h2>
    <div id="calendar" class="calendar"></div>
    <script>
    const calendar = document.getElementById('calendar');
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const honapok = [
        "Január", "Február", "Március", "Április", "Május", "Június",
        "Július", "Augusztus", "Szeptember", "Október", "November", "December"
    ];
    document.getElementById("monthTitle").textContent = honapok[month] + " " + year;

    const napok = ['Vas', 'Hét', 'Ked', 'Sze', 'Csü', 'Pén', 'Szo'];
    napok.forEach(n => {
        const div = document.createElement('div');
        div.textContent = n;
        div.style.fontWeight = 'bold';
        calendar.appendChild(div);
    });

    for (let i = 0; i < firstDay; i++) {
        const div = document.createElement('div');
        calendar.appendChild(div);
    }

    for (let d = 1; d <= daysInMonth; d++) {
        const div = document.createElement('div');
        div.textContent = d;
        if (d === today.getDate()) div.classList.add('today');
        div.style.cursor = 'pointer';
        div.onclick = () => {
            const datum = `${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
            window.location.href = `admin.php?lap=nap_szervezes&datum=${datum}`;
        };
        calendar.appendChild(div);
    }
    </script>
    <?php
    break;
}
?>
</div>

<script>
function toggleMenu() {
    const menu = document.getElementById('mobileMenu');
    menu.classList.toggle('show');
}
</script>

</body>
</html>
